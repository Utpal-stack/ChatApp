package com.example.chatapp.Models;

public class MassageModel {

    String uId, message, massageid;
    long timestamp;

    public MassageModel(String uId, String message, long timestamp) {
        this.uId = uId;
        this.message = message;
        this.timestamp = timestamp;
    }

    public MassageModel(String uId, String message) {
        this.uId = uId;
        this.message = message;
    }

    public String getMassageid() {
        return massageid;
    }

    public void setMassageid(String massageid) {
        this.massageid = massageid;
    }

    public MassageModel(){}

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
